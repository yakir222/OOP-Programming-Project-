//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MyPainter.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYPAINTER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_FILLCOLORBUTTON             1001
#define IDC_RADIO_ELLIPSE               1002
#define IDC_RADIO_RECTANGLE             1003
#define IDC_RADIO_TRIANGLE              1004
#define IDC_BUTTON_LOAD                 1007
#define IDC_BUTTON_SAVE                 1008
#define LIST_PENSIZE                    1009
#define IDC_PENCOLORBUTTON1             1010
#define IDC_PENCOLORBUTTON              1010
#define IDC_BUTTON_DRAW                 1011
#define IDC_BUTTON_SELECT               1012
#define IDC_LABEL_SHAPE                 1013
#define IDC_LABEL_FILLCOLOR             1014
#define IDC_LABEL_PENCOLOR              1015
#define IDC_BUTTON_ERASER               1017
#define IDC_STATIC_CANVAS               1019
#define IDC_BUTTON_FILL                 1022
#define IDC_BUTTON_CHNG_COLRS           1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
